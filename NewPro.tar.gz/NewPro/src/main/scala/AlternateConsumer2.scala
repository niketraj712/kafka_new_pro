import java.time.Duration

import org.apache.curator.framework.CuratorFrameworkFactory

import collection.JavaConverters._
import org.apache.curator.framework.recipes.atomic.{CachedAtomicLong, DistributedAtomicLong}
import org.apache.curator.retry.{ExponentialBackoffRetry, RetryNTimes}
import org.apache.kafka.clients.consumer.ConsumerRecord
import redis.clients.jedis.Jedis

object AlternateConsumer2 {

  def main(args: Array[String]): Unit = {
    val consumer = ConsumerCreator.createConsumer1
    val redis=new Redis()
    val jedis=redis.getJedis()
    val jedisPipe = jedis.pipelined()
    val curatorF=new CuratorF()
    val curator=curatorF.getCurator()


    val util=new Utilities()
    val distributedatomicLong = new DistributedAtomicLong(curator, "/", new RetryNTimes(3, 1000))
    var (startId, endId) = curatorF.getPool(distributedatomicLong)

    try {
      //  val Startime=System.currentTimeMillis()

      while (true) {

        val records1 = consumer.poll(Duration.ofMillis(10000))





        for (record <- records1.asScala) {

          (startId<endId) match {
            case true => {
              val key = record.value().split(",")(0)
              println(key, startId+ " by consumer 3")

              // jedis.set(key, startId.toString)
              //   println("record entered wth key "+key)
              //  jedisPipe.set(key,startId.toString)
              startId = startId + 1


              // print(startId)
            }
            case false => {

              val (startId1, endId1) = util.update(distributedatomicLong,record,curatorF,jedis,jedisPipe)

              startId=startId1
              endId=endId1


            }
          }
        }






        //  jedisPipe.sync()
        // val endtime=System.currentTimeMillis()
        //  println("Start time is "+Startime)
        //  println("end time is "+endtime)
        //  println("total time taken in millis "+(endtime-Startime))
      }



    }
    catch {

      case ex: Exception => {

        println(ex.printStackTrace())

      }
    }
  }
}

