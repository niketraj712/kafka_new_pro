import redis.clients.jedis.Jedis

import collection.JavaConverters._
object Verify {
  def main(args: Array[String]): Unit = {
    var count=0
    val jedis = new Jedis()
    var list: List[Integer] = List()
    val keys= jedis.keys("*")



      for(key<-keys.asScala){
        val v=jedis.get(key).toInt
        list = v :: list
        count=count+1






    }
    val newli=list.distinct
    println("count is "+count)
    println(newli.size)


  }
}