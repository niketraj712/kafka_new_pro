

import org.apache.curator.framework.recipes.atomic.{CachedAtomicLong, DistributedAtomicLong}
import org.apache.curator.framework.{CuratorFramework, CuratorFrameworkFactory}
import org.apache.curator.retry.{ExponentialBackoffRetry, RetryNTimes}





class CuratorF {

  def getCurator(): CuratorFramework = {
    val retryPolicy = new ExponentialBackoffRetry(1000, 3)
    val curator = CuratorFrameworkFactory.newClient("0.0.0.0:2181", retryPolicy)
    curator.start()
    return curator
  }


def getPool(distributedatomicLong: DistributedAtomicLong):(Long,Long) = {
  val poolsize = 100

  val cachedAtomicLong = new CachedAtomicLong(distributedatomicLong, poolsize);
  val startId = cachedAtomicLong.next().postValue();
  val endId = startId + poolsize

  return (startId,endId)
}}