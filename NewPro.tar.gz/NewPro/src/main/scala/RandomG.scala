import java.io.{BufferedWriter, File, FileOutputStream, OutputStreamWriter, PrintWriter}

object  RandomG {
  def main(args: Array[String]): Unit = {

    val ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

  val file = new File("/home/niket/Desktop/trial2.csv")
  val start: Long = System.currentTimeMillis
  val writer = new PrintWriter(new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8")), false)
  var counter = 0
  def randomAlphaNumeric(): String = {
    var count=20
    val builder = new StringBuilder
    while (count != 0) {
      val character = (Math.random * ALPHA_NUMERIC_STRING.length).toInt
      builder.append(ALPHA_NUMERIC_STRING.charAt(character))
      count=count-1
    }
    return builder.toString
  }
  while(counter!=601){
    val sep="\n"
    var line=randomAlphaNumeric()
    writer.print(sep)
    writer.print(line)
    counter=counter+1


  }
print("done writting")

}}
