import org.apache.spark.SparkConf
import org.apache.spark.api.java.{JavaRDD, JavaSparkContext}

object SpkRDD {
  def main(args: Array[String]): Unit = {
    val conf: SparkConf = new SparkConf().setMaster("local[*]").setAppName("SparkFileSumApp")
    val sc = new JavaSparkContext(conf)

    val input: JavaRDD[String] = sc.textFile("/home/niket/Desktop/ids.csv")
   println( input.count())

  }
}
