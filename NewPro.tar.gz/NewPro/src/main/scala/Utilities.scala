import org.apache.curator.framework.{CuratorFramework, CuratorFrameworkFactory}
import org.apache.curator.framework.recipes.atomic.{CachedAtomicLong, DistributedAtomicLong}
import org.apache.curator.retry.ExponentialBackoffRetry
import org.apache.kafka.clients.consumer.ConsumerRecord
import redis.clients.jedis.{Jedis, Pipeline, ShardedJedisPipeline}


class Utilities{

def update(distributedAtomicLong:DistributedAtomicLong,record:ConsumerRecord[String,String],curatorF: CuratorF,jedis: Jedis,jedisPipe:Pipeline):(Long,Long)={
  val distributedatomicLong1=distributedAtomicLong
  var (startId1, endId1) = curatorF.getPool(distributedatomicLong1)
  val key = record.value().split(",")(0)
  println(key, startId1)
  // jedis.set(key, startId1.toString)
    //jedisPipe.set(key,startId1.toString)
    //println("record entered with key "+key)
    startId1 = startId1 + 1


  return (startId1,endId1)


}

}