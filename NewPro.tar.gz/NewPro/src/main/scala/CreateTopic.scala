

  import java.util.Properties

  import kafka.admin.AdminUtils
  import kafka.utils.ZKStringSerializer
  import org.apache.kafka.common.utils.Time
  import org.I0Itec.zkclient.ZkClient
  object CreateTopic {
    // Create a ZooKeeper client
    def main(args: Array[String]): Unit = {
      val sessionTimeoutMs = 10000000
      val connectionTimeoutMs = 10000000
      // Note: You must initialize the ZkClient with ZKStringSerializer.  If you don't, then
      // createTopic() will only seem to work (it will return without error).  The topic will exist in
      // only ZooKeeper and will be returned when listing topics, but Kafka itself does not create the
      // topic.
      val zkClient = new ZkClient("0.0.0.0:2181", sessionTimeoutMs, connectionTimeoutMs,
        ZKStringSerializer)

      // Create a topic named "myTopic" with 8 partitions and a replication factor of 3
      val topicName = "top"
      val numPartitions = 6
      val replicationFactor = 1
      val topicConfig = new Properties
      AdminUtils.createTopic(zkClient, topicName, numPartitions, replicationFactor, topicConfig)
      print("topic created")

    }
  }