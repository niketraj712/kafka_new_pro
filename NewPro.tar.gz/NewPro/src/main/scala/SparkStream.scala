

import org.apache.avro.generic.GenericData.StringType
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.Dataset
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions
import org.apache.spark.sql.internal.SQLConf
import org.apache.spark.sql.streaming.OutputMode
import org.apache.spark.sql.streaming.StreamingQuery
import org.apache.spark.sql.streaming.StreamingQueryException
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.types.{DataType, IntegerType, StructField, StructType}


object SparkStream {
  def main(args: Array[String]): Unit = {
    System.setProperty("hadoop.home.dir", "c:/hadoop")
    Logger.getLogger("org.apache").setLevel(Level.WARN)
    Logger.getLogger("org.apache.spark.storage").setLevel(Level.ERROR)
    val session = SparkSession.builder.master("local[*]").appName("structuredViewingReport").getOrCreate

   // case class ID(id: Int, value: String)
   // session.conf.set("spark.sql.shuffle.partitions", "10")
    val results = session.readStream.format("kafka").option("kafka.bootstrap.servers", "localhost:9092").option("subscribe", "demo").load()
    // start some dataframe operations
    results.createOrReplaceTempView("tableview")

    // key, value, timestamp
    val results1 = session.sql("select cast(key as string),cast(value as string) from tableview")
//  val  myquery = session.sql("SELECT count(*) FROM tableview")

   //val query = results1.writeStream.format("console").outputMode(OutputMode.Update).option("truncate", false).option("numRows", 50).start
   // results1.show()
   // query.awaitTermination()

   val query = results1.writeStream
     .outputMode("append")
     .format("console").option("numRows", 500)
     .start()
    query.awaitTermination()
  }
}
