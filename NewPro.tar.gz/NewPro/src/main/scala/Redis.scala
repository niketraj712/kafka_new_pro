import org.apache.curator.framework.CuratorFramework
import redis.clients.jedis.Jedis

class Redis {
  def getJedis(): Jedis = {
    val jedis = new Jedis()

    return jedis
  }
}